with open(r'a.txt', 'r') as f:
    print(f.readlines())
    # print("###############")
    # print(f.read())
    # print("###############")
    # print(f.readline())
    # print("###############")


